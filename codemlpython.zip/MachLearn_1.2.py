import sys
import numpy as np
from math import *
from fonction2 import *
import nlopt
from numpy import *

def f1(x,grad1):

        global energy
        global inputs
        global nbrpoints
        global nbratoms
        global nbrneural

        neuraloutput = np.zeros(nbrpoints)
        neuralnetwork = np.zeros((nbrneural,nbrpoints))

        neuraloutput, neuralnetwork = MachLearn(x,inputs,nbrpoints,nbrneural,nbratoms)

        costfonction = np.sum((neuraloutput-energy)**2)/(2*nbrpoints)

        if grad1.size > 0:

                grad1[:] = MachLearnGrad(x,inputs,energy,neuralnetwork,neuraloutput,nbrpoints,nbrneural,nbratoms)

        return costfonction

def f2(x,grad2):

        global energy
        global inputs
        global nbrpoints
        global nbratoms
        global nbrneural
        global lambdaml

        neuraloutput = np.zeros(nbrpoints)
        neuralnetwork = np.zeros((nbrneural,nbrpoints))

        neuraloutput, neuralnetwork = MachLearn(x,inputs,nbrpoints,nbrneural,nbratoms)

        costfonction = np.sum((neuraloutput-energy)**2)/(2*nbrpoints) + (lambdaml*np.sum(x**2))/(2*nbrpoints)

        if grad2.size > 0:

                grad2[:] = MachLearnGrad_reg(x,inputs,energy,neuralnetwork,neuraloutput,nbrpoints,nbrneural,nbratoms,lambdaml)

        return costfonction

####################################################################################################
# INPUT POUR LE MACHINE LEARNING                                                                   #
####################################################################################################
nbrpoints = 12754
nbrpoints_test = 8343
nbrpoints_irc = 11
nbratoms = 10
nbrneural = 80
optimizer = nlopt.LD_LBFGS
ftol = 1.0E-16
xtol = 1.0E-16
trainingset = 'training_set_PES_631G.xyz'
testset = 'test_set_PES_631G.xyz'
ircpath = 'IRC_Path.xyz'
reg = 1
lambdaml = 0.0009
####################################################################################################

print "####################################################################################################"
print "#                MONONEURAL ALGORITHM FOR POTENTIAL ENERGY SURFACE MACHINE LEARING                 #"
print "#                                        PAR Bastien Casier                                        #"
print "#################################################################################################### \n"

#print "Nombre d'atomes : ", nbratoms, "\n"
	
#print "NOMBRE DE NEURONES : ", nbrneural, "\n" 
	
print ":::::::::: INITIALISATION :::::::::: \n"

####################################################################################################
# LAMBDA SET                                                                                       #
####################################################################################################

fircpath = open(ircpath, "r")

points_ircpath = np.zeros((nbrpoints_irc,nbratoms,4))
energy_irc = np.zeros(nbrpoints_irc)
position_irc = np.zeros(nbrpoints_irc)
count = -1

print ":::::::::: IRC PATH :::::::::: \n"

print "Ouverture du fichier contenant les geometries du /IRC PATH/ :", ircpath, "\n"

stop = 'n'

while (stop=='n'):
        line = fircpath.readline()
        w = line.split()
        if (w[0] == '10'):
                count = count + 1
                line = fircpath.readline()
                w = line.split()
                position_irc[count] = float(w[0])
                energy_irc[count] = float(w[1])
                for i in range(0,nbratoms):
                        line = fircpath.readline()
                        w = line.split()
                        points_ircpath[count,i,0] = float(w[1])
                        points_ircpath[count,i,1] = float(w[2])
                        points_ircpath[count,i,2] = float(w[3])
                        points_ircpath[count,i,3] = float(w[4])

        else:
                stop = 'y'

if (nbrpoints_irc == count+1):
        print "Nombre de geometries pour le /IRC PATH/ : OK"
        print "Total de geometries :", nbrpoints_irc, "\n "
else:
        print "Nombre de geometries pour le /IRC PATH/ : FAUX"

R2 = np.zeros(nbrpoints_irc-1)

for i in range(0,nbrpoints_irc-1):

        for at in range(0,nbratoms):

                R2[i] = R2[i] + (points_ircpath[i+1,at,1]-points_ircpath[i,at,1])**2 + (points_ircpath[i+1,at,2]-points_ircpath[i,at,2])**2 + (points_ircpath[i+1,at,3]-points_ircpath[i,at,3])**2

R2[:] = R2[:]/(3*nbratoms)

lambdaval = np.sum(R2)/len(R2)
lambdaval = 1/lambdaval

print "Valeur de la constante lambda (espace entre les points du IRC PATH) : ", lambdaval, "\n"

####################################################################################################

print ":::::::::: TRAINING SET :::::::::: \n"
	
print "Ouverture du fichier contenant les geometries du /training set/ :", trainingset, "\n"

#####################################################################################################
# TRAINING SET                                                                                      #
#####################################################################################################
	
fdataset = open(trainingset, "r")
	
points = np.zeros((nbrpoints,nbratoms,4))
energy = np.zeros(nbrpoints)
position = np.zeros(nbrpoints)
count = -1
	
stop = 'n'
	
while (stop=='n'):
	line = fdataset.readline()
	w = line.split()
	if (w[0] == '10'):
		count = count + 1
		line = fdataset.readline()
		w = line.split()
		position[count] = float(w[0])
		energy[count] = float(w[1])
		for i in range(0,nbratoms):
			line = fdataset.readline()
			w = line.split()
			points[count,i,0] = float(w[1])
			points[count,i,1] = float(w[2])
			points[count,i,2] = float(w[3])
			points[count,i,3] = float(w[4])
			
	else: 
		stop = 'y'
	
if (nbrpoints == count+1):
	print "Nombre de geometries pour le /training set/ : OK"
	print "Total de geometries :", nbrpoints
else:
	print "Nombre de geometries pour le /training set/ : FAUX"

coulombmatrix = np.zeros((nbrpoints,nbratoms,nbratoms))
for count in range(0,nbrpoints):
	for i in range(0,nbratoms):
		for j in range(0,nbratoms):
			if (i == j):
				coulombmatrix[count,i,j] = 0.5*points[count,i,0]**2.4
			else:
				Rx2 = (points[count,i,1] - points[count,j,1])**2
				Ry2 = (points[count,i,2] - points[count,j,2])**2
				Rz2 = (points[count,i,3] - points[count,j,3])**2
			
				R = sqrt(Rx2 + Ry2 + Rz2)

				coulombmatrix[count,i,j] = (points[count,i,0]*points[count,j,0])/R
	
inputs = np.zeros((nbratoms+nbrpoints_irc,nbrpoints))

for count in range(0,nbrpoints):
	eigenval, eigenvec = np.linalg.eig(coulombmatrix[count,:,:])
	for i in range(0, nbratoms):
		inputs[i,count] = eigenval[i]

	RMSE = rmsefonction(nbratoms,nbrpoints_irc,points_ircpath,lambdaval,points,count)
	for i in range(0,nbrpoints_irc):
		inputs[nbratoms+i,count] = RMSE[i]

#	maxinput = max(inputs[:,count])
#	mininput = min(inputs[:,count])
#	inputs[:,count] = (inputs[:,count] - mininput)/(maxinput - mininput)
		
#	s = sfonction(nbratoms,nbrpoints_irc,points_ircpath,lambdaval,points,count)
#	inputs[nbratoms,count] = s
#	rmse, z = szfonction(nbratoms,points_ircpath,points,count,inputs)
#	inputs[:,count] = np.log10(inputs[:,count])
#	inputs[nbratoms+1,count] = z

print "Calcul des Matrices Coulombiennes : OK \n"
	
maxenergy = max(energy[:])
minenergy = min(energy[:])
energy[:] = (energy[:]-minenergy)/(maxenergy - minenergy)

print "Energie minimale pour le /training set/ :", minenergy
print "Energie maximale pour le /training set/ :", maxenergy, "\n"

fdataset.close

#####################################################################################################
# TEST SET                                                                                          #
#####################################################################################################

ftestset = open(testset, "r")

points = np.zeros((nbrpoints_test,nbratoms,4))
energy_test = np.zeros(nbrpoints_test)
count = -1

print ":::::::::: TEST SET :::::::::: \n"

print "Ouverture du fichier contenant les geometries du /test set/ :", testset, "\n"

stop = 'n'

while (stop=='n'):
	line = ftestset.readline()
	w = line.split()
	if (w[0] == '10'):
		count = count + 1
		line = ftestset.readline()
		w = line.split()
		energy_test[count] = float(w[1])
		for i in range(0,nbratoms):
			line = ftestset.readline()
			w = line.split()
			points[count,i,0] = float(w[1])
			points[count,i,1] = float(w[2])
			points[count,i,2] = float(w[3])
			points[count,i,3] = float(w[4])

	else:
		stop = 'y'

if (nbrpoints_test == count+1):
	print "Nombre de geometries pour le /test set/ : OK"
	print "Total de geometries :", nbrpoints_test
else:
	print "Nombre de geometries pour le /test set/ : FAUX"

coulombmatrix = np.zeros((nbrpoints_test,nbratoms,nbratoms))
for count in range(0,nbrpoints_test):
	for i in range(0,nbratoms):
		for j in range(0,nbratoms):
			if (i == j):
				coulombmatrix[count,i,j] = 0.5*points[count,i,0]**2.4
			else:
				Rx2 = (points[count,i,1] - points[count,j,1])**2
				Ry2 = (points[count,i,2] - points[count,j,2])**2
				Rz2 = (points[count,i,3] - points[count,j,3])**2

				R = sqrt(Rx2 + Ry2 + Rz2)

				coulombmatrix[count,i,j] = (points[count,i,0]*points[count,j,0])/R

print "Calcul des Matrices Coulombiennes : OK \n"

tests = np.zeros((nbratoms+nbrpoints_irc,nbrpoints_test))

for count in range(0,nbrpoints_test):
	eigenval, eigenvec = np.linalg.eig(coulombmatrix[count,:,:])
	for i in range(0, nbratoms):
		tests[i,count] = eigenval[i]

	RMSE = rmsefonction(nbratoms,nbrpoints_irc,points_ircpath,lambdaval,points,count)
	for i in range(0,nbrpoints_irc):
		tests[nbratoms+i,count] = RMSE[i]

#        maxtest = max(tests[:,count])
#        mintest = min(tests[:,count])
#        tests[:,count] = (tests[:,count] - mintest)/(maxtest - mintest)


#	s = sfonction(nbratoms,nbrpoints_irc,points_ircpath,lambdaval,points,count)
#        tests[nbratoms,count] = s
#        rmse, z = szfonction(nbratoms,points_ircpath,points,count,tests)
#        tests[:,count] = np.log10(tests[:,count])
#        tests[nbratoms+1,count] = z

energy_test[:] = (energy_test[:]-minenergy)/(maxenergy - minenergy)

ftestset.close

##########################################################################################################################################################################################################

for lambdaml in (0.1,0.01,0.001,0.0001,0):

	print "####################################################################################################"

	print "Nombre d'atomes : ", nbratoms, "\n"

	print "NOMBRE DE NEURONES : ", nbrneural, "\n"

	print "Lambda pour regularisation : ", lambdaml, "\n"

####################################################################################################

	np.random.seed(1)

####################################################################################################
# INITIALISATION DE POIDS                                                                          #
####################################################################################################

	x = np.random.randn(nbrneural*(nbratoms+nbrpoints_irc))*0.01
	x = np.append(x,np.random.randn(nbrneural)*0.01)

####################################################################################################
# INITIALISATION DES BIAIS                                                                         #
####################################################################################################

	x = np.append(x,np.zeros(nbrneural))
	x = np.append(x,0.0)

####################################################################################################
# OPTIMISATION DU MACHINE LEARNING                                                                 #
####################################################################################################

	if (reg == 0):

		print ":::::::::: OPTIMIZATION :::::::::: \n"
	
		opt = nlopt.opt(optimizer,len(x))
	
		print "Optimisation realisee via la librairie : NLOpt "
		print "Steven G. Johnson, The NLopt nonlinear-optimization package \n"
		print "Methode :", opt.get_algorithm_name()
		print "Tolerance sur f (fonction de cout) - en valeur absolue :", ftol
		print "Tolerance sur w (poids du Machine Learning) - en valeur absolue :", xtol, "\n"
	
		opt.set_min_objective(f1)
	
		if ftol == 0.0:
			opt.set_xtol_abs(xtol)
		elif xtol == 0.0:
			opt.set_ftol_abs(ftol)
		else:
			opt.set_ftol_abs(ftol)
			opt.set_xtol_abs(xtol)
	
		xopt = opt.optimize(x)
	
		print "!!!!!!!!!! PARAMETRES OPTIMISES !!!!!!!!!! \n"
		print xopt, "\n"
	
		print "Valeur de la fonction de cout optimisee :", opt.last_optimum_value()
	
		neuraloutput, neuralnetwork = MachLearn(xopt,inputs,nbrpoints,nbrneural,nbratoms)
		RMSE = sqrt(np.sum((neuraloutput - energy)**2)/nbrpoints)

		print "RMSE(E) pour le /training set/ :", RMSE, "\n"

		Diff = np.transpose(neuraloutput - energy)

		print "Ecart maximum en energie pour les points du /training set/", max(Diff), "\n"

####################################################################################################
# REGULARISATION                                                                                   #
####################################################################################################

	else:

	        print ":::::::::: REGULARISATION :::::::::: \n"

        	opt = nlopt.opt(optimizer,len(x))

        	print "Optimisation realisee via la librairie : NLOpt "
        	print "Steven G. Johnson, The NLopt nonlinear-optimization package \n"
        	print "Methode :", opt.get_algorithm_name()
        	print "Tolerance sur f (fonction de cout) - en valeur absolue :", ftol
        	print "Tolerance sur w (poids du Machine Learning) - en valeur absolue :", xtol, "\n"

        	opt.set_min_objective(f2)

        	if ftol == 0.0:
                	opt.set_xtol_abs(xtol)
        	elif xtol == 0.0:
                	opt.set_ftol_abs(ftol)
        	else:
                	opt.set_ftol_abs(ftol)
                	opt.set_xtol_abs(xtol)

        	xopt = opt.optimize(x)

        	print "!!!!!!!!!! PARAMETRES OPTIMISES !!!!!!!!!! \n"
        	print xopt, "\n"

        	print "Valeur de la fonction de cout optimisee :", opt.last_optimum_value()

        	neuraloutput, neuralnetwork = MachLearn(xopt,inputs,nbrpoints,nbrneural,nbratoms)
        	RMSE = sqrt(np.sum((neuraloutput - energy)**2)/nbrpoints)

        	print "RMSE(E) pour le /training set/ :", RMSE, "\n"

        	Diff = np.transpose(neuraloutput - energy)

        	print "Ecart maximum en energie pour les points du /training set/", max(Diff), "\n"

####################################################################################################
# ENSEMBLE DE TEST SUR LA CONVERGENCE DU MACHINE LEARNING                                          #
####################################################################################################

	neuraloutput_test, neuralnetwork = MachLearn(xopt,tests,nbrpoints_test,nbrneural,nbratoms)
	RMSE_test = sqrt(np.sum((neuraloutput_test - energy_test)**2)/nbrpoints_test)

	print "RMSE(E) pour le /test set/ :", RMSE_test, "\n"

####################################################################################################
