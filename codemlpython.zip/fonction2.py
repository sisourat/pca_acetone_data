import sys
import numpy as np

def sigmoid(x):
        sigmoid = 1.0/(1.0 + np.exp(-x))
        return sigmoid

####################################################################################################

def MachLearn(x,inputs,nbrpoints,nbrneural,nbratoms):

	nbrpoints_irc = 11

	dimred = nbrneural*(nbratoms+nbrpoints_irc)

        neuralweigth1 = x[:(dimred)]
        neuralweigth1 = np.reshape(neuralweigth1,(nbrneural,nbratoms+nbrpoints_irc))
        neuralweigth2 = x[(dimred):(dimred+nbrneural)]
	neuralweigth2 = np.reshape(neuralweigth2,(nbrneural,1))
        biasneural1 = x[(dimred+nbrneural):(dimred+2*nbrneural)]
        biasneural2 = x[(dimred+2*nbrneural):]

	################################################################################
	# CALCUL L'ENERGIE ET L'ACTIVATION DU RESEAU DE NEURONES POUR CHAQUE STRUCTURE #
	################################################################################

	neuralnetwork = sigmoid(np.transpose(np.dot(neuralweigth1,inputs)) + biasneural1)
	neuraloutput = np.transpose(np.dot(neuralnetwork,neuralweigth2) + biasneural2)

	return (neuraloutput, neuralnetwork)

####################################################################################################

def MachLearnGrad_reg(x,inputs,energy,neuralnetwork,neuraloutput,nbrpoints,nbrneural,nbratoms,lambdaml):

	nbrpoints_irc = 11

        dcost_neuralweigth1 = np.zeros((nbrneural,(nbratoms+nbrpoints_irc)))
        dcost_neuralweigth2 = np.zeros(nbrneural)
        dcost_biasneural1 = np.zeros(nbrneural)
        dcost_biasneural2 = 0.0

        grad = np.zeros(len(x))

        dimred = nbrneural*(nbratoms+nbrpoints_irc)

        neuralweigth1 = x[:(dimred)]
        neuralweigth1 = np.reshape(neuralweigth1,(nbrneural,(nbratoms+nbrpoints_irc)))
        neuralweigth2 = x[(dimred):(dimred+nbrneural)]
        biasneural1 = x[(dimred+nbrneural):(dimred+2*nbrneural)]
        biasneural2 = x[(dimred+2*nbrneural):]

        #######################################
        # DERIVEE PAR RAPPORT A NEURALWEIGTH1 #
        #######################################

        dcost_neuralweigth1 = np.dot(inputs*(neuraloutput-energy),neuralweigth2*(neuralnetwork*(1-neuralnetwork)))/nbrpoints
        dcost_neuralweigth1 = np.transpose(dcost_neuralweigth1) + (lambdaml*neuralweigth1)/nbrpoints

        grad = np.reshape(dcost_neuralweigth1,(dimred))

        #######################################
        # DERIVEE PAR RAPPORT A NEURALWEIGTH2 #
        #######################################

        dcost_neuralweigth2 = np.dot((neuraloutput - energy),neuralnetwork)/nbrpoints + (lambdaml*neuralweigth2)/nbrpoints

        grad = np.append(grad,dcost_neuralweigth2)

        #####################################
        # DERIVEE PAR RAPPORT A BIASNEURAL1 #
        #####################################

        dcost_biasneural1 = np.dot((neuraloutput-energy),neuralweigth2*(neuralnetwork*(1-neuralnetwork)))/nbrpoints + (lambdaml*biasneural1)/nbrpoints

        grad = np.append(grad,dcost_biasneural1)

        #####################################
        # DERIVEE PAR RAPPORT A BIASNEURAL2 #
        #####################################

        dcost_biasneural2 = np.sum(neuraloutput - energy)/nbrpoints + (lambdaml*biasneural2)/nbrpoints

        grad = np.append(grad,dcost_biasneural2)

        return grad

####################################################################################################
		
def MachLearnGrad(x,inputs,energy,neuralnetwork,neuraloutput,nbrpoints,nbrneural,nbratoms):

	nbrpoints_irc = 11

        dcost_neuralweigth1 = np.zeros((nbrneural,nbratoms+nbrpoints_irc))
        dcost_neuralweigth2 = np.zeros(nbrneural)
        dcost_biasneural1 = np.zeros(nbrneural)
        dcost_biasneural2 = 0.0

        grad = np.zeros(len(x))

        dimred = nbrneural*(nbratoms+nbrpoints_irc)

        neuralweigth1 = x[:(dimred)]
        neuralweigth1 = np.reshape(neuralweigth1,(nbrneural,nbratoms+nbrpoints_irc))
        neuralweigth2 = x[(dimred):(dimred+nbrneural)]
        biasneural1 = x[(dimred+nbrneural):(dimred+2*nbrneural)]
        biasneural2 = x[(dimred+2*nbrneural):]

        #######################################
        # DERIVEE PAR RAPPORT A NEURALWEIGTH1 #
        #######################################

        dcost_neuralweigth1 = np.dot(inputs*(neuraloutput-energy),neuralweigth2*(neuralnetwork*(1-neuralnetwork)))/nbrpoints
        dcost_neuralweigth1 = np.transpose(dcost_neuralweigth1)

        grad = np.reshape(dcost_neuralweigth1,(dimred))

        #######################################
        # DERIVEE PAR RAPPORT A NEURALWEIGTH2 #
        #######################################

        dcost_neuralweigth2 = np.dot((neuraloutput - energy),neuralnetwork)/nbrpoints

        grad = np.append(grad,dcost_neuralweigth2)

        #####################################
        # DERIVEE PAR RAPPORT A BIASNEURAL1 #
        #####################################

        dcost_biasneural1 = np.dot((neuraloutput-energy),neuralweigth2*(neuralnetwork*(1-neuralnetwork)))/nbrpoints

        grad = np.append(grad,dcost_biasneural1)

        #####################################
        # DERIVEE PAR RAPPORT A BIASNEURAL2 #
        #####################################

        dcost_biasneural2 = np.sum(neuraloutput - energy)/nbrpoints

        grad = np.append(grad,dcost_biasneural2)

        return grad

####################################################################################################

def rmsefonction(nbratoms,nbrpoints_irc,points_ircpath,lambdaval,points,pts):

        R2 = np.zeros(nbrpoints_irc)

        for i in range(0,nbrpoints_irc):

                for at in range(0,nbratoms):

                        R2[i] = R2[i] + (points[pts,at,1]-points_ircpath[i,at,1])**2 + (points[pts,at,2]-points_ircpath[i,at,2])**2 + (points[pts,at,3]-points_ircpath[i,at,3])**2

        
	R2[:] = R2[:]/3*nbratoms

        return R2

####################################################################################################
# S FONCTION                                                                                       #
####################################################################################################

def szfonction(nbratoms,points_ircpath,points,pts,inputs):

	s = 0.0
	
	for at in range(0,nbratoms):

		s = s + (points[pts,at,1]-points_ircpath[0,at,1])**2 + (points[pts,at,2]-points_ircpath[0,at,2])**2 + (points[pts,at,3]-points_ircpath[0,at,3])**2		

	s = s/3*nbratoms
	
	z = 1.0

        for j in range(0,nbratoms):
                z = z*inputs[j,pts]

	return s, z

####################################################################################################
# S FONCTION                                                                                       #
####################################################################################################

def spfonction(nbratoms,nbrpoints_irc,points_ircpath,lambdaval,points,pts):

        R2 = np.zeros(nbrpoints_irc)
        R2f = np.zeros(nbrpoints_irc)
        R2i = np.zeros(nbrpoints_irc)

        for i in range(0,nbrpoints_irc):

                for at in range(0,nbratoms):

                        R2[i] = R2[i] + (points[pts,at,1]-points_ircpath[i,at,1])**2 + (points[pts,at,2]-points_ircpath[i,at,2])**2 + (points[pts,at,3]-points_ircpath[i,at,3])**2

                R2[i] = R2[i]/3*nbratoms

	p = np.sum(R2[:])/lambdaval

        return p

###################################################################################################
